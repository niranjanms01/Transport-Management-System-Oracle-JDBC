package transportmanagementsystem;

public class TransportManagementSystem {
    public static void main(String[] args) {
        System.out.println("Transport Management System");
    }
}
