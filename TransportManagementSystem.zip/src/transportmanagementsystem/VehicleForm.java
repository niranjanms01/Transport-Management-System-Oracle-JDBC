package transportmanagementsystem;

public class VehicleForm extends javax.swing.JFrame {
    public VehicleForm() {
        initComponents();
    }
    private void initComponents() {}
}
