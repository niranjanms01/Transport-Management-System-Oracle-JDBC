CREATE TABLE VEHICLES (
    vehicle_id NUMBER PRIMARY KEY,
    vehicle_name VARCHAR2(50),
    vehicle_type VARCHAR2(30),
    capacity NUMBER
);
